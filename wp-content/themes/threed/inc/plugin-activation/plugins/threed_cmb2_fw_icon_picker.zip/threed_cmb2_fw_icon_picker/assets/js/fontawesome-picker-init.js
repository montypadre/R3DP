
jQuery(document).ready(function($) {
  'use strict';
  $('.fontawesome-icon-select').iconpicker({
    hideOnSelect: true
  });
}); // End Ready
